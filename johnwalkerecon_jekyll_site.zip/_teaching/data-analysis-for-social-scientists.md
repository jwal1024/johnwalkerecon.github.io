---
title: "Data Analysis for Social Scientists"
layout: default
---

**Institution:** MIT Department of Economics  
**Role:** Lead Teaching Assistant (3 terms, 2021–2022)  
**Instructor:** Prof. Sara Fisher Ellison  

Course introducing causal inference, experimental design, and regression analysis using Stata and R.
