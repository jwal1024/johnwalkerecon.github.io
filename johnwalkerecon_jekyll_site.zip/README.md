# John Walker — Academic Website (Jekyll)

This repository hosts the Jekyll site for **johnwalkerecon.github.io**.

## Local development
- Install Ruby and Bundler
- `bundle init && bundle add jekyll`
- `bundle exec jekyll serve`

Or simply push to GitHub and enable **Pages → Deploy from a branch**.
