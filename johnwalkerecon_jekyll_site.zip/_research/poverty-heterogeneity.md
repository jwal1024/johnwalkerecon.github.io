---
title: "Heterogeneity in Effects of Poverty-Alleviating Interventions"
layout: default
---

**Garlick, Walker & Orkin (2025)**  
*AEA Papers and Proceedings, 115, 1–5.*

Short summary: This paper studies how the effects of poverty-alleviating interventions vary across baseline mental health and socioeconomic gradients, combining randomized cash transfer data with machine learning estimates of treatment heterogeneity.
