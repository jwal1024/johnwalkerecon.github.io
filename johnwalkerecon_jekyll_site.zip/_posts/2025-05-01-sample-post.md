---
layout: post
title: "Field Experiments and Mental Health: A Research Note"
---

In our ongoing project in Chiradzulu District, Malawi, we study the interaction between cash transfers and mental health using a randomized saturation design...
